package puertonaviero;

public class Puerto {

    private Barcos velero;
    private Barcos lancha;
    private Barcos motoAcuatica;

    public Puerto(Velero velero, Lancha lancha, MotoAcuatica motoAcuatica) {
        this.velero = velero;
        this.lancha = lancha;
        this.motoAcuatica = motoAcuatica;
    }

    public void imprimirPuerto(){
        System.out.println("Por favor, elija el barco que desea alquilar");
        System.out.println("1."+this.velero);
        System.out.println("2."+this.lancha);
        System.out.println("3."+this.motoAcuatica);

    }

}
