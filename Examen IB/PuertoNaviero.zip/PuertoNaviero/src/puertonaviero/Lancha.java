package puertonaviero;

public class Lancha extends Barcos implements pagosImpuestos{
    private double tamanioFletera; //es el espacio para el trafico de mercancia o personas

    private double transmision;
    private String nombreLancha;

    public Lancha(double peso, double consumoCombustible, double longitudEmbarcacion,double velocidadMaxima, String tipo, double tamanioFletera, double transmision,String nombreLancha) {
        super(peso, consumoCombustible, longitudEmbarcacion,velocidadMaxima, tipo);
        this.tamanioFletera = tamanioFletera;
        this.transmision = transmision;
        this.nombreLancha = nombreLancha;
    }

    public double getTamanioFletera() {
        return tamanioFletera;
    }

    public void setTamanioFletera(double tamanioFletera) {
        this.tamanioFletera = tamanioFletera;
    }

    public double getTransmision() {
        return transmision;
    }

    public void setTransmision(double transmision) {
        this.transmision = transmision;
    }

    public String getNombreLancha() {
        return nombreLancha;
    }

    public void setNombreLancha(String nombreLancha) {
        this.nombreLancha = nombreLancha;
    }
    public double tasaAduana(){
        return this.transmision*.15*super.longitudEmbarcacion;
    }
    public double tasaCapacidadCarga(){
        return super.consumoCombustible*.18 + super.longitudEmbarcacion*10;
    }
    public double tasaVelocidad(){
        return super.velocidadMaxima*.07*super.peso;
    }
    public String mostrarPago(){
        double a = this.tasaAduana() + this.tasaCapacidadCarga() + this.tasaVelocidad();
        return "Hay que pagar de aduanas: "+this.tasaAduana()+", hay que pagar de capacidad de carga: "+this.tasaCapacidadCarga()+ ", y hay que pagar de tasa de velocidad: "+this.tasaVelocidad() +"\n"+
                "Y el total es de: "+a;
    }
    public String toString(){
        return super.toString() + " De nombre: "+this.nombreLancha+" de tamaño de fletera de: "+this.tamanioFletera + " y de transmision:" +transmision;
    }
}
