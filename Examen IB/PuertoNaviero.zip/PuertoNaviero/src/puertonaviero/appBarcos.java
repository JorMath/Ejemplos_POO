package puertonaviero;

import java.util.InputMismatchException;
import java.util.Scanner;

public class appBarcos {
    public static void main(String [] args){
        int eleccion=0;
        String mostrar = "";
        Scanner sc = new Scanner(System.in);
        Velero velero = new Velero(1000,0,10,60,"Velero",10,10,"Mandra");
        Lancha lancha = new Lancha(500,20,5,80,"Lancha",100,50,"Sigma");
        MotoAcuatica motoacuatica = new MotoAcuatica(100,10,2,200,"Moto acuatica","Biplaza",65,"FreeRide","Redbull acuatic");
        Puerto puerto = new Puerto(velero,lancha,motoacuatica);
        uno:
        while(true) {

            try {
                System.out.println("Por favor escoje el barco que deseas elegir, para el velero = 1, para la lancha = 2, para la moto = 3");
                puerto.imprimirPuerto();
                System.out.println();
                eleccion = sc.nextInt();
                if (eleccion == 1) {
                    System.out.println(velero);
                    mostrar = velero.mostrarPago();
                    System.out.println(mostrar);
                    break uno;
                }
                else{
                    if(eleccion==2){
                        System.out.println(lancha);
                        mostrar = lancha.mostrarPago();
                        System.out.println(mostrar);
                        break uno;
                    }
                    else{
                        if(eleccion ==3){
                            System.out.println(motoacuatica);
                            mostrar = motoacuatica.mostrarPago();
                            System.out.println(mostrar);
                            break uno;
                        }
                        else{
                            if(eleccion !=1 && eleccion !=2 &&eleccion !=3){
                                throw new InputMismatchException();
                            }
                        }
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Elige correctamente, no ingreses numeros que no estan o letras");
                sc.nextLine();
                continue uno;
            }

        }

    }


}



