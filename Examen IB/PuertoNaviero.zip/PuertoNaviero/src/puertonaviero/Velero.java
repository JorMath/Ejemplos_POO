package puertonaviero;

public class Velero extends Barcos implements pagosImpuestos{
    private double longitudMastil1; //para colocar las velas
    private double longitudMastil2;
    private String nombreVelero;

    public Velero(double peso, double consumoCombustible, double longitudEmbarcacion,double velocidadMaxima, String tipo, double longitudMastil1, double longitudMastil2, String nombreVelero) {
        super(peso, consumoCombustible, longitudEmbarcacion,velocidadMaxima,tipo);
        this.longitudMastil1 = longitudMastil1;
        this.longitudMastil2 = longitudMastil2;
        this.nombreVelero = nombreVelero;
    }

    public double getLongitudMastil1() {
        return longitudMastil1;
    }

    public void setLongitudMastil1(double longitudMastil1) {
        this.longitudMastil1 = longitudMastil1;
    }

    public double getGetLongitudMastil2() {
        return longitudMastil2;
    }

    public void setGetLongitudMastil2(double getLongitudMastil2) {
        this.longitudMastil2 = getLongitudMastil2;
    }

    public String getNombreVelero() {
        return nombreVelero;
    }

    public void setNombreVelero(String nombreVelero) {
        this.nombreVelero = nombreVelero;
    }
    public double tasaAduana(){
        return this.longitudMastil1*.15*super.peso;
    }
    public double tasaCapacidadCarga(){
        return super.consumoCombustible*.12*super.velocidadMaxima*super.longitudEmbarcacion;
    }
    public double tasaVelocidad(){
        return super.velocidadMaxima*.05*this.longitudMastil2;
    }
    public String mostrarPago(){
        double a = this.tasaAduana() + this.tasaCapacidadCarga() + this.tasaVelocidad();
        return "Hay que pagar de aduanas: "+this.tasaAduana()+", hay que pagar de capacidad de carga: "+this.tasaCapacidadCarga()+ ", y hay que pagar de tasa de velocidad: "+this.tasaVelocidad() +"\n"+
                "Y el total es de: "+a;
    }
    public String toString(){
        return super.toString() + " De longitud de mastiles de:"+this.longitudMastil1+" y "+this.longitudMastil2+" y el nombre del " +
                "velero es: "+this.nombreVelero;
    }
}
