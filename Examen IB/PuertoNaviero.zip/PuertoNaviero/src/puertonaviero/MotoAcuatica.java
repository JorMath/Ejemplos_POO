package puertonaviero;

public class MotoAcuatica extends Barcos implements pagosImpuestos{

    private String tipodePlaza; //si hay uno o mas pasajeros
    private double potencia;
    private String modalidadMoto; //si es para carreras o de uso libre, por ejemplo
    private String nombreMoto;


    public MotoAcuatica(double peso, double consumoCombustible, double longitudEmbarcacion,double velocidadMaxima, String tipo, String tipodePlaza, double potencia, String modalidadMoto,String nombreMoto) {
        super(peso, consumoCombustible, longitudEmbarcacion,velocidadMaxima, tipo);
        this.tipodePlaza = tipodePlaza;
        this.potencia = potencia;
        this.modalidadMoto = modalidadMoto;
        this.nombreMoto = nombreMoto;
    }

    public String getTipodePlaza() {
        return tipodePlaza;
    }

    public void setTipodePlaza(String tipodePlaza) {
        this.tipodePlaza = tipodePlaza;
    }

    public double getPotencia() {
        return potencia;
    }

    public void setPotencia(double potencia) {
        this.potencia = potencia;
    }

    public String getModalidadMoto() {
        return modalidadMoto;
    }

    public void setModalidadMoto(String modalidadMoto) {
        this.modalidadMoto = modalidadMoto;
    }

    public String getNombreMoto() {
        return nombreMoto;
    }

    public void setNombreMoto(String nombreMoto) {
        this.nombreMoto = nombreMoto;
    }
    public double tasaAduana(){
        return this.potencia*.15*super.peso;
    }
    public double tasaCapacidadCarga(){
        return super.consumoCombustible*.12;
    }
    public double tasaVelocidad(){
        return super.velocidadMaxima*.05*super.longitudEmbarcacion;
    }
    public String mostrarPago(){
        double a = this.tasaAduana() + this.tasaCapacidadCarga() + this.tasaVelocidad();
        return "Hay que pagar de aduanas: "+this.tasaAduana()+", hay que pagar de capacidad de carga: "+this.tasaCapacidadCarga()+ ", y hay que pagar de tasa de velocidad: "+this.tasaVelocidad() +"\n"+
                "Y el total es de: "+a;
    }
    public String toString(){

        return super.toString() +"Con el nombre de: "+this.nombreMoto+ " de tipo de plaza: "+this.tipodePlaza + " de potencia "+this.potencia + "y con modalidad de: "+this.modalidadMoto;
    }
}
