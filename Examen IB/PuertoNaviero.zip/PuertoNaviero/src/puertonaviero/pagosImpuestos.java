package puertonaviero;

public interface pagosImpuestos {

    double tasaAduana();
    double tasaCapacidadCarga();
    double tasaVelocidad();
}
