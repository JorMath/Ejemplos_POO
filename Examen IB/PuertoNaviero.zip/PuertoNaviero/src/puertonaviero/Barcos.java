package puertonaviero;

public abstract class Barcos {
    protected double peso;
    protected double consumoCombustible;
    protected double longitudEmbarcacion;
    protected double velocidadMaxima;
    protected String tipo;




    public Barcos(double peso, double consumoCombustible, double longitudEmbarcacion, double velocidadMaxima,String tipo) {
        this.peso = peso;
        this.consumoCombustible = consumoCombustible;
        this.longitudEmbarcacion = longitudEmbarcacion;
        this.velocidadMaxima = velocidadMaxima;
        this.tipo = tipo;
    }


    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getConsumoCombustible() {
        return consumoCombustible;
    }

    public void setConsumoCombustible(double consumoCombustible) {
        this.consumoCombustible = consumoCombustible;
    }

    public double getLongitudEmbarcacion() {
        return longitudEmbarcacion;
    }

    public void setLongitudEmbarcacion(double longitudEmbarcacion) {
        this.longitudEmbarcacion = longitudEmbarcacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(double velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }
    public abstract String mostrarPago();
    public String toString(){
        return "El barco de tipo: "+this.tipo+" de peso: "+this.peso + " que consume esta cantidad de combustible: "+this.consumoCombustible+" de velocidad maxima de:"+this.velocidadMaxima
                +" y su longitud es de:"+this.longitudEmbarcacion;
    }

}
