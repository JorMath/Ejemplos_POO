package alquiler;

public interface CCQ {

     public double impuestoEmpresa();
     public double impuestoUsoNoPersonal();
}
