package alquiler;
/* Los metodos de las interfaces son por defecto publicos, se puede omitir la palabra public*/
public interface SRI {

    public double impAduana();
    public double IR();
    public String formulario();



}
