package alquiler;

public interface AMT {

    public double matricula();
    public double revision();

}
